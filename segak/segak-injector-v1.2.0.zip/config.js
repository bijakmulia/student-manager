/* ============================================================
   TETAPAN PENJUAL — ubah fail ini sahaja sebelum muat naik
   ============================================================ */
self.SEGAK_CONFIG = {
  // Edisi percuma Bijak Mulia: semua ciri (termasuk autopilot sekelas) dibuka tanpa kod lesen.
  FREE_ALL: true,

  // Kunci awam RSA untuk semak kod lesen. JANGAN ubah kecuali awk jana kunci baharu dalam penjana-lesen.html.
  PUBLIC_KEY: {"kty":"RSA","n":"pVosMLuYyPkt5PskU_Uzr05ssSWZMkIjGmX8KHU7Oup_Ik6VaEhGDP2cB5IGTqyM1_Vpeq1edc6KMmvU5dOZ_dF7ECpoKlyzBYCsGJolORSqtNXQ6XRrKTfLq1ImgG4tp7nPmOrXtonmSANxZPRjvFQgqNCZEQ8RR53UcTeRmmUzL_Ws_3mJFExEiiIVtqGM6gUf3FnFQTbi5RkhY80YGP-18o_BO61gW7yrTeW-lXNRk2v8N2C1_gJS8h55CKIpmNqgMeqhLl6zLcMp7asVZMOGPLAnhklKQfPjdQhDIaLMZEw-h57EVVCOtUuhNtEFAf5V-Xi-tOC8qQtbxOOLUQ","e":"AQAB"},

  // URL kedai (Google Apps Script web app, berakhir dengan /exec).
  // Contoh: 'https://script.google.com/macros/s/AKfycb.../exec'
  // Boleh juga WhatsApp: 'https://wa.me/60123456789'
  BUY_URL: 'https://script.google.com/macros/s/AKfycbxTy_w9-P1pAkeYr3nCon09JcJ1KZPbyyCIbdyp1Y_s2y4VTEnkFZmQPjKV46pdEjwL/exec',

  // Teks harga pada butang Beli (kosongkan '' jika tak nak papar)
  PRICE: 'dari RM5',

  // Pakej dipapar dalam tab ⭐ Pro (harga sebenar ditetapkan di kedai Apps Script)
  PLANS: [
    { harga: 'RM5', tempoh: '1 minggu' },
    { harga: 'RM10', tempoh: '1 tahun' },
    { harga: 'RM29', tempoh: 'seumur hidup', best: true }
  ],

  // Cubaan percuma autopilot (jumlah murid sepanjang hayat pemasangan). 0 = tiada cubaan.
  TRIAL_STUDENTS: 5
};
