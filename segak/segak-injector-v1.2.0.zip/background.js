/* SEGAK Injector — service worker: butang toolbar & notifikasi */
const SPPB = 'https://moeissppb.moe.gov.my/';
const notifTab = {};

chrome.action.onClicked.addListener(async tab => {
  if (tab && tab.url && tab.url.startsWith(SPPB)) {
    try { await chrome.tabs.sendMessage(tab.id, { type: 'open' }); } catch (e) { /* halaman belum siap */ }
  } else {
    chrome.tabs.create({ url: SPPB });
  }
});

chrome.runtime.onMessage.addListener((m, sender) => {
  if (!m || m.type !== 'notify') return;
  chrome.notifications.create('', {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: String(m.title || 'SEGAK Injector'),
    message: String(m.text || ''),
    priority: 2
  }, id => { if (sender.tab) notifTab[id] = { tab: sender.tab.id, win: sender.tab.windowId }; });
});

chrome.notifications.onClicked.addListener(id => {
  const t = notifTab[id];
  if (t) { chrome.windows.update(t.win, { focused: true }); chrome.tabs.update(t.tab, { active: true }); }
  chrome.notifications.clear(id);
  delete notifTab[id];
});
